﻿namespace ChitChat.Infrastructure.Repositories;

public interface IConnectionRepository : IRepository<Connection>
{

}