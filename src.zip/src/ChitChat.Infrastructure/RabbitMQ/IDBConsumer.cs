﻿namespace ChitChat.Infrastructure.RabbitMQ;

public interface IDBConsumer
{
    void Connect();
}