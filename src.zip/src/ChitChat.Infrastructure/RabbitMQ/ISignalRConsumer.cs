﻿namespace ChitChat.Infrastructure.RabbitMQ;

public interface ISignalRConsumer
{
    void Connect();
}