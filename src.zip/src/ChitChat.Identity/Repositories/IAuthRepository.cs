﻿namespace ChitChat.Identity.Repositories;

public interface IAuthRepository : IRepository<RefreshToken>
{

}
