﻿namespace ChitChat.Identity.Repositories;

public interface IUserRepository : IRepository<User>
{

}
