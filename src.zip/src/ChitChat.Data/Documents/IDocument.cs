﻿namespace ChitChat.Data.Documents;

public interface IDocument
{
    string Id { get; set; }
}
