﻿namespace ChitChat.Data.DTOs;

public class CacheEntryDTO
{
    public string Key { get; set; } = string.Empty;
    public string Value { get; set; } = string.Empty;
}
